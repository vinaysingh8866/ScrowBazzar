/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {ScrowBazzarContract} from './ScrowBazzar';

export {ScrowBazzarContract} from './ScrowBazzar';

export const contracts: any[] = [ScrowBazzarContract];
